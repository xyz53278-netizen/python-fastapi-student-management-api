# Python Application Development — Student Management REST API

A beginner-friendly REST API built with **FastAPI, SQLAlchemy, and SQLite**. It demonstrates routing, HTTP methods, database storage, CRUD operations, API-key authentication, request validation, and automated endpoint tests.

## Features
- Create, list, retrieve, update, and delete student records
- SQLite database storage via SQLAlchemy ORM
- API-key authentication for create, update, and delete operations
- Pydantic request schema validation
- Duplicate email checks and useful HTTP status codes
- Interactive API documentation at `/docs`
- Automated tests using Pytest and FastAPI TestClient

## Tech Stack
Python 3.10+ · FastAPI · SQLite · SQLAlchemy · Pydantic · Pytest

## Project Structure
```text
python-application-development-api/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── tests/
    └── test_app.py
```

## Setup

### 1. Create and activate a virtual environment

Windows:
```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:
```bash
python -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies
```bash
python -m pip install -r requirements.txt
```

### 3. Configure the API key

For a quick local learning run, the app has a development fallback key `dev-secret-change-me`. For any shared or deployed environment, set a unique secret in the `API_KEY` environment variable before starting the app. Do not commit real secrets to GitHub.

Windows PowerShell:
```powershell
$env:API_KEY="replace-with-a-long-random-secret"
```

macOS/Linux:
```bash
export API_KEY="replace-with-a-long-random-secret"
```

### 4. Start the server
```bash
uvicorn app:app --reload
```

Open:
- API root: http://127.0.0.1:8000/
- Interactive Swagger docs: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

## API Endpoints

| Method | Endpoint | Authentication | Purpose |
|---|---|---|---|
| GET | `/` | No | API status |
| GET | `/students` | No | List students |
| GET | `/students/{student_id}` | No | Get one student |
| POST | `/students` | API key | Create student |
| PUT | `/students/{student_id}` | API key | Update student |
| DELETE | `/students/{student_id}` | API key | Delete student |

Protected endpoints require the `X-API-Key` request header.

### Example: Create a student
```bash
curl -X POST "http://127.0.0.1:8000/students" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: dev-secret-change-me" \
  -d '{"name":"Kamal Dhaka","email":"kamal@example.com","course":"AI & DS"}'
```

Example response:
```json
{
  "id": 1,
  "name": "Kamal Dhaka",
  "email": "kamal@example.com",
  "course": "AI & DS"
}
```

Use your configured `API_KEY` value instead of the development fallback when you set one.

## Run Tests
```bash
python -m pytest -q
```

Tests use a separate SQLite database under the `tests/` directory. The database file is ignored by Git.

## Learning Outcomes
- Build routes and endpoints with FastAPI
- Understand GET, POST, PUT, and DELETE
- Persist records in SQLite
- Validate request bodies with Pydantic
- Protect selected endpoints using an API key
- Test successful, unauthorized, invalid, and not-found responses

## Security Notes
This is an educational starter project, not production-ready authentication. The example API key is a development fallback only; configure a strong secret for any shared environment. For production, use a managed secrets store, HTTPS, robust identity/authentication, authorization, rate limiting, and additional database migration and validation practices.

## Author
**Kamal Dhaka** — B.Tech Artificial Intelligence & Data Science Student
