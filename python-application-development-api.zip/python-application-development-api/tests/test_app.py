import os
from pathlib import Path

# Use a dedicated temporary SQLite database for tests.
test_db = Path(__file__).with_name("test_students.db")
if test_db.exists():
    test_db.unlink()
os.environ["DATABASE_URL"] = f"sqlite:///{test_db}"
os.environ["API_KEY"] = "test-key"

from fastapi.testclient import TestClient
from app import app, Base, engine

client = TestClient(app)
HEADERS = {"X-API-Key": "test-key"}


def setup_function():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)


def test_root_and_docs():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["docs"] == "/docs"


def test_create_requires_api_key():
    response = client.post(
        "/students",
        json={"name": "Kamal Dhaka", "email": "kamal@example.com", "course": "AI & DS"},
    )
    assert response.status_code == 401


def test_student_crud():
    payload = {"name": "Kamal Dhaka", "email": "kamal@example.com", "course": "AI & DS"}

    created = client.post("/students", json=payload, headers=HEADERS)
    assert created.status_code == 201
    student_id = created.json()["id"]

    fetched = client.get(f"/students/{student_id}")
    assert fetched.status_code == 200
    assert fetched.json()["name"] == "Kamal Dhaka"

    updated_payload = {"name": "Kamal D.", "email": "kamal@example.com", "course": "Data Science"}
    updated = client.put(
        f"/students/{student_id}", json=updated_payload, headers=HEADERS
    )
    assert updated.status_code == 200
    assert updated.json()["course"] == "Data Science"

    deleted = client.delete(f"/students/{student_id}", headers=HEADERS)
    assert deleted.status_code == 204

    missing = client.get(f"/students/{student_id}")
    assert missing.status_code == 404


def test_schema_validation():
    response = client.post(
        "/students",
        json={"name": "K", "email": "x", "course": "A"},
        headers=HEADERS,
    )
    assert response.status_code == 422
